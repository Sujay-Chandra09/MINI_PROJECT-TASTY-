package com.tasty.tasty.model;

public class Ingredient {

    private String name;
    private int quantity;
    private String unit;
    private int price;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public int getPrice() { return price; }
    public void setPrice(int price) { this.price = price; }
}