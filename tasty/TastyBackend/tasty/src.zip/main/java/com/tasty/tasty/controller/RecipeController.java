package com.tasty.tasty.controller;

import com.tasty.tasty.model.Recipe;
import com.tasty.tasty.model.Comment;
import com.tasty.tasty.repository.RecipeRepository;
import com.tasty.tasty.model.User;
import com.tasty.tasty.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;
import org.bson.types.ObjectId;

import java.util.List;
import java.util.ArrayList;

@RestController
@CrossOrigin
@RequestMapping("/recipes")
public class RecipeController {

    private final RecipeRepository recipeRepository;
    private final UserRepository userRepository;

    public RecipeController(RecipeRepository recipeRepository, UserRepository userRepository) {
        this.recipeRepository = recipeRepository;
        this.userRepository = userRepository;
    }

    // 👉 GET ALL RECIPES
    @GetMapping
    public List<Recipe> getAllRecipes(){
        return recipeRepository.findAll();
    }

    // 👉 ADD RECIPE
    @PostMapping
    public Recipe addRecipe(@RequestBody Recipe recipe) {
        return recipeRepository.save(recipe);
    }

    // 👉 LIKE RECIPE
    @PostMapping("/{id}/like")
    public Recipe likeRecipe(@PathVariable("id") String id, HttpServletRequest request) {
        if(!ObjectId.isValid(id)) return null;
        ObjectId objId = new ObjectId(id);

        String userIdStr = (String) request.getAttribute("userId");
        if(userIdStr == null) throw new RuntimeException("Not Authenticated");
        ObjectId userId = new ObjectId(userIdStr);

        Recipe recipe = recipeRepository.findById(objId).orElse(null);
        User user = userRepository.findById(userId).orElse(null);

        if (recipe != null && user != null) {
            
            // Initialize arrays if null
            if (recipe.getLikedBy() == null) recipe.setLikedBy(new ArrayList<>());
            if (user.getFavorites() == null) user.setFavorites(new ArrayList<>());

            // Toggle logic
            if (recipe.getLikedBy().contains(userId)) {
                recipe.getLikedBy().remove(userId);
                recipe.setLikeCount(Math.max(0, recipe.getLikeCount() - 1));
                user.getFavorites().remove(objId);
            } else {
                recipe.getLikedBy().add(userId);
                recipe.setLikeCount(recipe.getLikeCount() + 1);
                user.getFavorites().add(objId);
            }

            userRepository.save(user);
            recipeRepository.save(recipe);
        }
        return recipe;
    }

    // 👉 ADD COMMENT
    @PostMapping("/{id}/comments")
    public Recipe addComment(@PathVariable("id") String id, @RequestBody Comment comment, HttpServletRequest request) {
        if(!ObjectId.isValid(id)) return null;

        String userIdStr = (String) request.getAttribute("userId");
        if(userIdStr == null) throw new RuntimeException("Not Authenticated");
        ObjectId userId = new ObjectId(userIdStr);

        User user = userRepository.findById(userId).orElse(null);
        String realName = (user != null && user.getName() != null) ? user.getName() : "Anonymous User";
        comment.setCommenterName(realName);

        ObjectId objId = new ObjectId(id);
        Recipe recipe = recipeRepository.findById(objId).orElse(null);
        if (recipe != null) {
            if (recipe.getComments() == null) {
                recipe.setComments(new ArrayList<>());
            }
            recipe.getComments().add(comment);
            recipeRepository.save(recipe);
        }
        return recipe;
    }

    // 👉 GET SINGLE RECIPE
    @GetMapping("/{id}")
    public Recipe getRecipeById(@PathVariable("id") String id){
        if(!ObjectId.isValid(id)) return null;
        ObjectId objId = new ObjectId(id);
        return recipeRepository.findById(objId).orElse(null);
    }

    // 👉 QUANTITY
    @GetMapping("/{id}/quantity")
    public Recipe calculateQuantity(
            @PathVariable("id") String id,
            @RequestParam("members") int members){
        if(!ObjectId.isValid(id)) return null;
        ObjectId objId = new ObjectId(id);
        Recipe recipe = recipeRepository.findById(objId).orElse(null);
        if(recipe == null) return null;
        recipe.getIngredients().forEach(i -> {
            i.setQuantity(i.getQuantity() * members);
        });
        return recipe;
    }

    // 👉 SEARCH
    @GetMapping("/search")
    public List<Recipe> searchRecipe(@RequestParam("name") String name){
        List<Recipe> recipes = recipeRepository.searchByTitle(name);
        return recipes.stream().limit(20).toList();
    }

    // 👉 RECOMMEND
    @PostMapping("/recommend")
    public List<Recipe> recommendRecipes(@RequestBody List<String> ingredients){
        List<Recipe> result = new ArrayList<>();
        for(String ing : ingredients){
            result.addAll(recipeRepository.recommendRecipes(ing));
        }
        return result.stream().distinct().limit(20).toList();
    }

    // 👉 TIME FILTER
    @GetMapping("/filter/time")
    public List<Recipe> filterByTime(@RequestParam("minutes") int minutes){
        return recipeRepository.findByCookingTimeLessThanEqual(minutes);
    }

    // 👉 BUDGET FILTER
    @GetMapping("/filter/budget")
    public List<Recipe> filterByBudget(@RequestParam("amount") int amount){
        List<Recipe> allRecipes = recipeRepository.findAll();
        List<Recipe> result = new ArrayList<>();
        for(Recipe r : allRecipes){
            int totalCost = r.getIngredients()
                             .stream()
                             .mapToInt(i -> i.getPrice())
                             .sum();
            if(totalCost <= amount){
                result.add(r);
            }
        }
        return result.stream().limit(20).toList();
    }

}