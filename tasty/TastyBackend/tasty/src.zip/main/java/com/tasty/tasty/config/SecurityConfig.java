package com.tasty.tasty.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity   // ⭐ VERY IMPORTANT ⭐
public class SecurityConfig {

    private final JwtFilter jwtFilter;

    public SecurityConfig(JwtFilter jwtFilter){
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
            .csrf(csrf -> csrf.disable())

            // ❌ Disable Spring Default Login
            .formLogin(form -> form.disable())
            .httpBasic(basic -> basic.disable())

            // ⭐ VERY VERY IMPORTANT FOR JWT
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )

            .authorizeHttpRequests(auth -> auth

                // 🔓 GUEST APIs
                .requestMatchers("/recipes/**").permitAll()
                .requestMatchers("/users/signup").permitAll()
                .requestMatchers("/users/login").permitAll()

                // 🔐 PROTECTED APIs
                .requestMatchers("/users/favorite/**").authenticated()
                .requestMatchers("/users/favorites").authenticated()

                .anyRequest().permitAll()  // ⭐ MUST BE permitAll
            )

            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}